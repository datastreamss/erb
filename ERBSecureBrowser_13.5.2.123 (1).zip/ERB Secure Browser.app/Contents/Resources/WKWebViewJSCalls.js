//Getters  with params
external = {};

var __itsSbTickCountVar = 0;

function setTickCount(ticks) {
    __itsSbTickCountVar = parseInt(ticks);
}

try {
    if(top.__itsSbTickCountVar !== undefined) {
        external.GetTickCount = function () {
            return top.__itsSbTickCountVar;
        };
    }
} catch {
    // todo: prompt getTickcount here
    external.GetTickCount = function () {
        var res = prompt("external:GetTickCount");
        return parseInt(res);
    };
}

external.GetProcessHash = function(fileName) {
    var res = prompt("external:GetProcessHash", fileName);
    return res;
};
external.GetProcessCandidateCDHashFull = function(processName) {
    var res = prompt("external:GetProcessCandidateCDHashFull", processName);
    return res;
};
external.PlayAudio = function(fileName) {
    var res = prompt("external:PlayAudio", fileName);
    return parseInt(res);
};
external.Retrieve = function(fileName) {
    var res = prompt("external:Retrieve", fileName);
    return res;
};
external.SaveRecording = function(uploadURLString) {
    var res = prompt("external:SaveRecording", uploadURLString);
    return parseInt(res);
};
external.GetToken = function(publicKey) {
    var res = prompt("external:GetToken", publicKey);
    return res;
};
external.View = function(filePath) {
    var res = prompt("external:View", filePath);
    return parseInt(res);
};
external.DownloadDataFilesAsync = function(testName) {
    var res = prompt("external:DownloadDataFilesAsync", testName);
    return parseInt(res);
};
external.GetValue = function(key) {
    var res = prompt("external:GetValue", key);
    return res;
};
external.CheckFirewall = function(url) {
    var res = prompt("external:CheckFirewall", url);
    return parseInt(res);
};

//Getters  without params
external.GetResultID = function() {
    var res = prompt("external:GetResultID");
    return res;
};
external.GetProgramID = function() {
    var res = prompt("external:GetProgramID");
    return res;
};
external.GetProcessor = function() {
    var res = prompt("external:GetProcessor");
    return res;
};
external.GetMachineID = function() {
    var res = prompt("external:GetMachineID");
    return res;
};
external.GetMACAddress = function() {
    var res = prompt("external:GetMACAddress");
    return res;
};
external.GetSerial = function() {
    var res = prompt("external:GetSerial");
    return res;
};
external.GetSecureBrowserType = function() {
    var res = prompt("external:GetSecureBrowserType");
    return res;
};
external.GetBrowserType = function() {
    var res = prompt("external:GetBrowserType");
    return res;
};
external.GetSecureBrowserVersion = function() {
    var res = prompt("external:GetSecureBrowserVersion");
    return res;
};
external.GetSystemMemory = function() {
    var res = prompt("external:GetSystemMemory");
    return res;
};
external.GetUUID = function() {
    var res = prompt("external:GetUUID");
    return res;
};
external.GetProcesses = function() {
    var res = prompt("external:GetProcesses");
    return res;
};
external.GetRecordingDuration = function() {
    var res = prompt("external:GetRecordingDuration");
    return parseInt(res);
};
external.GetPlatform = function() {
    var res = prompt("external:GetPlatform");
    return res;
};
external.GetPath = function() {
    var res = prompt("external:GetPath");
    return res;
};
external.GetOSVersion = function() {
    var res = prompt("external:GetOSVersion");
    return res;
};
external.GetNetworkUser = function() {
    var res = prompt("external:GetNetworkUser");
    return res;
};
external.GetNetworkType = function() {
    var res = prompt("external:GetNetworkType");
    return res;
};
external.GetLanguageCode = function() {
    var res = prompt("external:GetLanguageCode");
    return res;
};
external.GetGUID = function() {
    var res = prompt("external:GetGUID");
    return res;
};
external.GetFingerprint = function() {
    var res = prompt("external:GetFingerprint");
    return res;
};
external.GetActiveMACAddress = function() {
    var res = prompt("external:GetActiveMACAddress");
    return res;
};
external.GetActiveIPAddress = function() {
    var res = prompt("external:GetActiveIPAddress");
    return res;
};
external.GetModel = function() {
    var res = prompt("external:GetModel");
    return res;
};
external.GetNetworkName = function() {
    var res = prompt("external:GetNetworkName");
    return res;
};
external.GetPrinters = function() {
    var res = prompt("external:GetPrinters");
    return res;
};
external.GetLogFile = function() {
    var res = prompt("external:GetLogFile");
    return res;
};
external.ClearClipboard = function() {
    var res = prompt("external:ClearClipboard");
    return parseInt(res);
};
external.StopRecording = function() {
    var res = prompt("external:StopRecording");
    return parseInt(res);
};
external.StopAudio = function() {
    var res = prompt("external:StopAudio");
    return parseInt(res);
};
external.ContinueAudio = function() {
    var res = prompt("external:ContinueAudio");
    return parseInt(res);
};
external.ContinueRecording = function() {
    var res = prompt("external:ContinueRecording");
    return parseInt(res);
};
external.DeleteRecording = function() {
    var res = prompt("external:DeleteRecording");
    return parseInt(res);
};
external.DoNetworkDiag = function() {
    var res = prompt("external:DoNetworkDiag");
    return res;
};
external.PauseAudio = function() {
    var res = prompt("external:PauseAudio");
    return parseInt(res);
};
external.PauseRecording = function() {
    var res = prompt("external:PauseRecording");
    return parseInt(res);
};
external.PlayRecording = function() {
    var res = prompt("external:PlayRecording");
    return parseInt(res);
};
external.QueryAudioBrowserVersion = function() {
    var res = prompt("external:QueryAudioBrowserVersion");
    return res;
};
external.QueryAudioLength = function() {
    var res = prompt("external:QueryAudioLength");
    return parseInt(res);
};
external.QueryAudioProgress = function() {
    var res = prompt("external:QueryAudioProgress");
    return parseInt(res);
};
external.QueryBrowserPath = function() {
    var res = prompt("external:QueryBrowserPath");
    return res;
};
external.QueryWaveFormat = function() {
    var res = prompt("external:QueryWaveFormat");
    return res;
};
external.QueryRecordingName = function() {
    var res = prompt("external:QueryRecordingName");
    return res;
};
external.GetDefaultPath = function() {
    var res = prompt("external:GetDefaultPath");
    return res;
};
external.QueryVolume = function() {
    var res = prompt("external:QueryVolume");
    return parseInt(res);
};
external.GetSupportedMethods = function() {
    var res = prompt("external:GetSupportedMethods");
    return res;
};
//Void without params
external.GetMessages = function() {
    var res = prompt("external:GetMessages");
    return res;
};
external.ClearLog = function() {
    var res = prompt("external:ClearLog");
    return res;
};
external.Copy = function() {
    var res = prompt("external:Copy");
    return res;
};
external.Cut = function() {
    var res = prompt("external:Cut");
    return res;
};
external.DisableSecurity = function() {
    var res = prompt("external:DisableSecurity");
    return res;
};
external.CloseBrowser = function() {
    var res = prompt("external:CloseBrowser");
    return res;
};
//external.CloseWindow = function() {
//    var res = prompt("external:CloseWindow");
//    return res;
//};
external.CloseWindows = function() {
    var res = prompt("external:CloseWindows");
    return res;
};
external.KillApplication = function() {
    var res = prompt("external:KillApplication");
    return res;
};
external.Undo = function() {
    var res = prompt("external:Undo");
    return res;
};
external.StopWebSocketServer = function() {
    var res = prompt("external:StopWebSocketServer");
    return res;
};
external.DisableRefresh = function() {
    var res = prompt("external:DisableRefresh");
    return res;
};
external.EnableRefresh = function() {
    var res = prompt("external:EnableRefresh");
    return res;
};
external.GoToAlternateURL = function() {
    var res = prompt("external:GoToAlternateURL");
    return res;
};
external.GoToDefaultURL = function() {
    var res = prompt("external:GoToDefaultURL");
    return res;
};
external.Hide = function() {
    var res = prompt("external:Hide");
    return res;
};
external.MaximizeSecureBrowser = function() {
    var res = prompt("external:MaximizeSecureBrowser");
    return res;
};
external.MinimizeSecureBrowser = function() {
    var res = prompt("external:MinimizeSecureBrowser");
    return res;
};
external.Paste = function() {
    var res = prompt("external:Paste");
    return res;
};
external.Redo = function() {
    var res = prompt("external:Redo");
    return res;
};
external.Show = function() {
    var res = prompt("external:Show");
    return res;
};
external.ConfigureAlternateURL = function(urlString) {
    var res = prompt("external:ConfigureAlternateURL", urlString);
    return res;
};
external.ConfigureDomainWhitelist = function(newWhitelist) {
    var res = prompt("external:ConfigureDomainWhitelist", newWhitelist);
    return res;
};
external.ConfigureLogPath = function(newLogPath) {
    var res = prompt("external:ConfigureLogPath", newLogPath);
    return res;
};
external.ConfigureBlacklist = function(pipeDelimitedBlacklist) {
    var res = prompt("external:ConfigureBlacklist", pipeDelimitedBlacklist);
    return res;
};
external.ConfigureWhitelist = function(pipeDelimitedBlacklist) {
    var res = prompt("external:ConfigureWhitelist", pipeDelimitedBlacklist);
    return res;
};
external.ExitSecureBrowser = function(exitCode) {
    var res = prompt("external:ExitSecureBrowser", exitCode);
    return res;
};
external.LaunchApplication = function(appName) {
    var res = prompt("external:LaunchApplication", appName);
    return res;
};
external.LogMessage = function(logMessage) {
    var res = prompt("external:LogMessage", logMessage);
    return res;
};
external.MonitorApplication = function(applicationName) {
    var res = prompt("external:MonitorApplication", applicationName);
    return res;
};
external.PrintDialog = function(frameName) {
    var res = prompt("external:PrintDialog", frameName);
    return res;
};
external.PrintSilent = function(frameName) {
    var res = prompt("external:PrintSilent", frameName);
    return res;
};
external.SetGUID = function(value) {
    var res = prompt("external:SetGUID", value);
    return res;
};
external.SetInstitution = function(aValue) {
    var res = prompt("external:SetInstitution", aValue);
    return res;
};
external.SetInstitutionID = function(aValue) {
    var res = prompt("external:SetInstitutionID", aValue);
    return res;
};
external.SetLanguage = function(aValue) {
    var res = prompt("external:SetLanguage", aValue);
    return res;
};
external.SetParameters = function(text) {
    var res = prompt("external:SetParameters", text);
    return res;
};
external.SetProgram = function(aValue) {
    var res = prompt("external:SetProgram", aValue);
    return res;
};
external.SetProgramID = function(aValue) {
    var res = prompt("external:SetProgramID", aValue);
    return res;
};
external.LogTestComplete = function(fileContent) {
    var res = prompt("external:LogTestComplete", fileContent);
    return res;
};
external.VerifyDataFileStatusAsync = function(testName) {
    var res = prompt("external:VerifyDataFileStatusAsync", testName);
    return res;
};
external.StartHiddenURL = function(urlString) {
    var res = prompt("external:StartHiddenURL", urlString);
    return res;
};
external.SetResultID = function(resultID) {
    var res = prompt("external:SetResultID", resultID);
    return res;
};
external.SetResultId = function(resultID) {
    var res = prompt("external:SetResultId", resultID);
    return res;
};
external.Activate = function(applicationName) {
    var res = prompt("external:Activate", applicationName);
    return res;
};
external.EnableSecurity = function(newLevel) {
    var res = prompt("external:EnableSecurity", newLevel);
    return res;
};
external.ConfigureAllowTaskSwitching = function(allow) {
    var res = prompt("external:ConfigureAllowTaskSwitching", allow);
    return res;
};
external.ConfigureAllowVirtualMachine = function(allow) {
    var res = prompt("external:ConfigureAllowVirtualMachine", allow);
    return res;
};
external.ConfigureExitIfApplicationNotPaused = function(shouldExit) {
    var res = prompt("external:ConfigureExitIfApplicationNotPaused", shouldExit);
    return res;
};
external.ConfigureExitIfBlacklistNotPaused = function() {
    var res = prompt("external:ConfigureExitIfBlacklistNotPaused");
    return res;
};
external.ConfigureExitIfCtrlAltDel = function(shouldExit) {
    var res = prompt("external:ConfigureExitIfCtrlAltDel", shouldExit);
    return res;
};
external.ConfigureLogging = function(nowEnabled) {
    var res = prompt("external:ConfigureLogging", nowEnabled);
    return res;
};
external.SetDataFileBasePath = function(baseUrl) {
    var res = prompt("external:SetDataFileBasePath", baseUrl);
    return res;
};


//Boolean without params
external.IsApplicationConnected = function() {
    var res = prompt("external:IsApplicationConnected");
    return Boolean(parseInt(res));
};
external.IsApplicationRunning = function() {
    var res = prompt("external:IsApplicationRunning");
    return Boolean(parseInt(res));
};
external.IsBlacklistProcessRunning = function() {
    var res = prompt("external:IsBlacklistProcessRunning");
    return Boolean(parseInt(res));
};
external.IsDownloadPrintBrowser = function() {
    var res = prompt("external:IsDownloadPrintBrowser");
    return Boolean(parseInt(res));
};
external.IsNetworkCache = function() {
    var res = prompt("external:IsNetworkCache");
    return Boolean(parseInt(res));
};
external.IsNetworkPath = function() {
    var res = prompt("external:IsNetworkPath");
    return Boolean(parseInt(res));
};
external.IsRecordingComplete = function() {
    var res = prompt("external:IsRecordingComplete");
    return Boolean(parseInt(res));
};
external.IsRemoteDesktopEnabled = function() {
    var res = prompt("external:IsRemoteDesktopEnabled");
    return Boolean(parseInt(res));
};
external.IsSecurityEnabled = function() {
    var res = prompt("external:IsSecurityEnabled");
    return Boolean(parseInt(res));
};
external.IsVirtualMachine = function() {
    var res = prompt("external:IsVirtualMachine");
    return Boolean(parseInt(res));
};
external.IsSecure = function() {
    var res = prompt("external:IsSecure");
    return Boolean(parseInt(res));
};
external.RestoreApplicationPreferences = function() {
    var res = prompt("external:RestoreApplicationPreferences");
    return Boolean(parseInt(res));
};
external.GetCameraAccess = function() {
    var res = prompt("external:GetCameraAccess");
    return Boolean(parseInt(res));
};
external.GetMicrophoneAccess = function() {
    var res = prompt("external:GetMicrophoneAccess");
    return Boolean(parseInt(res));
};
external.IsWireless = function() {
    var res = prompt("external:IsWireless");
    return Boolean(parseInt(res));
};


external.EnvironmentCheck = function(filePath, appName) {
    var params = filePath + "$$" + appName;
    var res = prompt("external:EnvironmentCheck", params);
    return parseInt(res);
};
external.ConfigureViolationURL = function(violationURL, types) {
    var params = violationURL + "$$" + types;
    var res = prompt("external:ConfigureViolationURL", params);
    return res;
};
external.SetValue = function(key, value) {
    var params = key + "$$" + value;
    var res = prompt("external:SetValue", params);
    return res;
};
external.Store = function(fileName, fileContent) {
    var params = fileName + "$$" + fileContent;
    var res = prompt("external:Store", params);
    return Boolean(parseInt(res));
};
external.SetLanguageText = function(key, text) {
    var params = key + "$$" + text;
    var res = prompt("external:SetLanguageText", params);
    return res;
};
external.SetConfiguration = function(programID, institutionCode) {
    var params = programID + "$$" + institutionCode;
    var res = prompt("external:SetConfiguration", params);
    return res;
};
external.ReplayRecording = function(urlString, cacheFileName) {
    var params = urlString + "$$" + cacheFileName;
    var res = prompt("external:ReplayRecording", params);
    return parseInt(res);
};
external.ReadinessLaunch = function(applicationplistFilePath, appName) {
    var params = applicationplistFilePath + "$$" + appName;
    var res = prompt("external:ReadinessLaunch", params);
    return res;
};
external.AppCheckIfFilesInstalled = function(testName, language) {
    var params = testName + "$$" + language;
    var res = prompt("external:AppCheckIfFilesInstalled", params);
    return parseInt(res);
};
external.SetPageSetup = function(pageSize, pageOrient) {
    var params = pageSize + "$$" + pageOrient;
    var res = prompt("external:SetPageSetup", params);
    return res;
};
external.StartRecording = function(type, quality, defaultVolume, volume) {
    var params = type + "$$" + quality + "$$" + defaultVolume + "$$" + volume;
    var res = prompt("external:StartRecording", params);
    return parseInt(res);
};
external.ConfigureSecurity = function(pipeDelimitedWhitelist, pipeDelimitedBlacklist, vmBlocked, allowAppSwitching) {
    var params = pipeDelimitedWhitelist + "$$" + pipeDelimitedBlacklist + "$$" + vmBlocked + "$$" + allowAppSwitching;
    var res = prompt("external:ConfigureSecurity", params);
    return res;
};
external.DownloadAndPrintPDF = function(urlString, requestedDownloadPath, printerName) {
    var params = urlString + "$$" + requestedDownloadPath + "$$" + printerName;
    var res = prompt("external:DownloadAndPrintPDF", params);
    return parseInt(res);
};

external.IsSecureBrowser = true;

function setupWebViewJavascriptBridge(callback) {
    if (window.WebViewJavascriptBridge) {
        return callback(WebViewJavascriptBridge);
    }
    if (window.WVJBCallbacks) {
        return window.WVJBCallbacks.push(callback);
    }
    window.WVJBCallbacks = [callback];
    var WVJBIframe = document.createElement('iframe');
    WVJBIframe.style.display = 'none';
    WVJBIframe.src = 'https://__bridge_loaded__';
    document.documentElement.appendChild(WVJBIframe);
    setTimeout(function() {
        document.documentElement.removeChild(WVJBIframe)
    }, 0)
};
external.MonitorProcess = function() {
    var sbArgs = arguments;

    setupWebViewJavascriptBridge(function(bridge) {
        bridge.callHandler('MonitorProcess', {
            'params': [{
                ...sbArgs
            }]
        }, function(response) {
            if (sbArgs.length == 4) {
                sbArgs[3](response);
            }
        });
    });
}

//OpenBook API

external.getTabs = function() {
    var res = prompt("external:getTabs");
    return res;
};

external.closeTab = function(ident) {
    var res = prompt("external:closeTab", ident);
    return res;
};
external.startTabUI = function(config) {
    var res = prompt("external:startTabUI", JSON.stringify(config));
    return res;
};

external.endTabUI = function() {
    var res = prompt("external:endTabUI");
    return res;
};

external.addTab = function(options, tabJavaScriptAccessible) {
    var params = options + "$$" + tabJavaScriptAccessible;
    var res = prompt("external:addTab", params);
    return res;
};
external.addTabEventListener = function(eventName, callBack) {
    var params = eventName + "$$" + callBack;
    var res = prompt("external:addTabEventListener", params);
    return res;
};

//    ACROBAT LISTENER JSCALLS

external.StartAcrobatListener = function(port, callback) {
    var sbArgs = arguments;

    setupWebViewJavascriptBridge(function(bridge) {
        bridge.callHandler('StartAcrobatListener', {
            'params': [{
                ...sbArgs
            }]
        }, function(response) {
            {
                sbArgs[1](response);
            }
        });
    });
}

external.CopyAcrobatDocument = function (source, destination, override) {
    var params = source + "$$" + destination + "$$" + override;
    var res = prompt("external:CopyAcrobatDocument", params);
    return res;
};

external.InitLita = function() {
    var res = prompt("external:InitLita");
    return res;
};

external.RestoreFiles = function (resultId, workingPath) {
    var params = resultId + "$$" + workingPath;
    var res = prompt("external:RestoreFiles", params);
    return res;
};

external.BackupFiles = function (resultID, pristineFilePath, workingFilePath, workingBasePath) {
    var params = resultID + "$$" + pristineFilePath + "$$" + workingFilePath + "$$" + workingBasePath;
    var res = prompt("external:BackupFiles", params);
    return res;
};

external.StopAcrobatListener = function() {
    var res = prompt("external:StopAcrobatListener");
    return res;
};
external.SetupApplicationWindow = function(applicationWidth) {
    var res = prompt("external:SetupApplicationWindow", applicationWidth);
    return res;
};
external.SendToAcrobat = function(result) {
    var res = prompt("external:SendToAcrobat", result);
    return res;
};

external.CheckAccessibilityPermission = function() {
    var res = prompt("external:CheckAccessibilityPermission");
    return Boolean(parseInt(res));
};

external.OpenSystemSettings = function(accessibilityString) {
    var res = prompt("external:OpenSystemSettings",accessibilityString);
    return res;
};

external.GetSpeechRecognitionAccess = function() {
    var res = prompt("external:GetSpeechRecognitionAccess");
    return res;
};

external.GetLastHeartbeat = function() {
    var res = prompt("external:GetLastHeartbeat");
    return res;
};
//when ever window.close calls we are calling CloseBrowser
window.close = function() {external.CloseBrowser();};

//when ever window.close calls we are calling CloseBrowser
window.print = function() {external.windowPrint();};

external.windowPrint = function() {
    var res = prompt("external:windowPrint");
    return res;
};

//Newly added jscalls
//external.SetSessionProperties = function(string) {
//    
//    var res = prompt("external:SetSessionProperties", JSON.stringify(string));
//    return res;
//};
//
//
//external.GetSessionProperties = function() {
//    var res = prompt("external:GetSessionProperties");
//    return res;
//};
